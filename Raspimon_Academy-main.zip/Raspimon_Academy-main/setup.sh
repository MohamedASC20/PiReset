pip3 install google-cloud-vision; pip3 install opencv-contrib-python==4.1.0.25; sudo apt-get install -y libatlas-base-dev libhdf5-dev libhdf5-serial-dev libjasper-dev  libqtgui4  libqt4-test
sudo apt-get update
sudo apt-get install sense-hat
sudo apt-get install python-sense-emu python3-sense-emu python-sense-emu-doc sense-emu-tools -y
pip3 install pynput
