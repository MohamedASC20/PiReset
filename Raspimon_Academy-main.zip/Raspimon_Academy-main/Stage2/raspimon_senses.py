from sense_hat import SenseHat
from time import sleep

sense = SenseHat()

#declare a temperature variable and assign it the value of sense.get_temperature()


#print out type statements:

print(type("Hello!"))



#make a while True loop



    #add conditional statements to test
