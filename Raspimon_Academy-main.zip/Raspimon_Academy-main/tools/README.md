# Tools
Here are scripts & examples to improve your productivity.

## To clone the project from GitHub
1. Create a new file at $HOME/Desktop/cloneRaspimon.sh by copying [cloneRaspimon.sh](./cloneRaspimon.sh).
2. Make it executable to run it at a Terminal.
```bash
$ cd $HOME/Desktop
$ chmod +x ./cloneRaspimon.sh
$ ./cloneRaspimon.sh
```
3. The project will be clone at $HOME/Desktop/Raspimon_Academy.
4. A few useful cheat sheets will be opened on the Web Browser.
