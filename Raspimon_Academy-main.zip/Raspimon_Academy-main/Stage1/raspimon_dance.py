from sense_hat import SenseHat
from time import sleep


sense = SenseHat()

#load the Raspimons you want to animate




for i in range(20):
  #animate your raspimon!
  
  
#while True:
  #dance forever!